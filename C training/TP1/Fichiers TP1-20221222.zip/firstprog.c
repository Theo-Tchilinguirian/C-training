/*  firstprog.c 
    Compiler avec : 
    gcc -Wall firstprog.c -o firstprog
*/

#include <stdio.h>

int main()
{
	printf("Félicitation ! Vous avez réussi à compiler et exécuter un programme en C \n ");
	return 0;
}
